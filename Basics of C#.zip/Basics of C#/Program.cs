﻿using System;


namespace Basics_of_C_
{
    class MainClass
    {
        static void Main()
        {
            Task1_BasicInputCalculation.CalculateDifference();

            int lowNumber, highNumber;
            Task2_LoopingInputValidation.GetValidNumbers(out lowNumber, out highNumber);

            Task3_ArraysFileIO.ProcessNumbers(lowNumber, highNumber);
        }
    }
}