﻿using System;

namespace Basics_of_C_
{
    class Task1_BasicInputCalculation
    {
        public static void CalculateDifference()
        {
            Console.WriteLine("Enter the low number:");
            int lowNumber = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the high number:");
            int highNumber = int.Parse(Console.ReadLine());

            int difference = highNumber - lowNumber;
            Console.WriteLine($"The difference between {highNumber} and {lowNumber} is {difference}.");
        }
    }
}
