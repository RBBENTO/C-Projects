﻿using System;


namespace Basics_of_C_
{
    class Task2_LoopingInputValidation
    {
        public static void GetValidNumbers(out int lowNumber, out int highNumber)
        {
            do
            {
                Console.WriteLine("Enter a positive low number:");
                lowNumber = int.Parse(Console.ReadLine());
            } while (lowNumber <= 0);

            do
            {
                Console.WriteLine("Enter a high number greater than the low number:");
                highNumber = int.Parse(Console.ReadLine());
            } while (highNumber <= lowNumber);
        }
    }
}
