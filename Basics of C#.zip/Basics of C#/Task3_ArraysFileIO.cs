﻿using System;


namespace Basics_of_C_
{
    class Task3_ArraysFileIO
    {
        public static void ProcessNumbers(int lowNumber, int highNumber)
        {
            List<int> numbers = new List<int>();
            for (int i = lowNumber; i <= highNumber; i++)
            {
                numbers.Add(i);
            }

            string filePath = "numbers.txt";
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (var number in numbers)
                {
                    writer.WriteLine(number);
                }
            }

            double sum = 0;
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    sum += double.Parse(line);
                }
            }

            Console.WriteLine($"The sum of the numbers is {sum}.");

            Console.WriteLine("Prime numbers between low and high:");
            foreach (var num in numbers)
            {
                if (IsPrime(num))
                {
                    Console.WriteLine(num);
                }
            }
        }

        static bool IsPrime(int number)
        {
            if (number < 2) return false;
            for (int i = 2; i <= Math.Sqrt(number); i++)
            {
                if (number % i == 0) return false;
            }
            return true;
        }
    }
}
