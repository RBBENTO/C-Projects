﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.Utility
{
    public class SiglyLinkedList : ILinkedListADT
    {
        public Node Head;

        //Adds an elemnt at the end of the list
        public void AddLast(User value)
        {
            Node temp=Head;
            Node node = new Node(value);
            //checks if the list is empty
            if (Head == null)
            {
                //Makes the head point to the node in case the list is empty
                Head = node;
            }
            //otherwise appends the element at the end of the list
            else 
            {
                while (temp.Next != null)
                {
                    temp = temp.Next;
                }
                temp.Next = node;
            }
            
        }

        public void AddFirst(User value)
        {
            Node node = new Node(value);
            //checks if the list is empty
            if (Head == null)
            {
                //Makes the head point to the node in case the list is empty
                Head = node;
            }
            //otherwise adds the element at the begining
            else
            {
                node.Next = Head;
                Head = node;
            }
        }
        //Removes an element at the specified index 
        public void Remove(int index)
        {
            try
            {
                Node temp = Head;
                int count = 0;

                while (count != index-1)
                {
                    count++;
                    if (temp.Next == null)
                    {
                        throw new IndexOutOfRangeException();
                    }
                    else 
                    {
                        temp = temp.Next;
                    }
                }
                temp.Next = temp.Next.Next;
            }
            catch (IndexOutOfRangeException e) 
            {
                Console.WriteLine(e.Message);
            }
        }
        //removing the first element of the list
        public void RemoveFirst()
        {
            try
            { 
                //if the list is empty, an exception is thrown
                if(Head == null)
                {
                    throw new CannotRemoveException();
                }
                else
                {
                    Head = Head.Next;
                }
            }
            catch(CannotRemoveException e) 
            {
                Console.WriteLine(e.Message);
            }
        }

        //rremoving the last element from the list
        public void RemoveLast()
        {
            try
            { 
                //if the list is empty, an exception gets thrown
                if (Head == null)
                {
                    throw new CannotRemoveException();
                }
                else
                {
                    Node node = Head;
                    while(node.Next.Next != null)
                    {
                        node = node.Next;
                    }
                    node.Next = null;
                }

            }
            catch(CannotRemoveException e) 
            {
                Console.WriteLine(e.Message);
            }
                
               
        }

        //Adds an element at a specific position 
        public void Add(User value, int index)
        {
            try
            {
                Node Value = new Node(value);
                Node temp = Head;
                int count = 0;
                //if the index is zero,Addfirst() method is  used to add the element
                if (index == 0)
                {
                    AddFirst(value);
                }
                //throws an exception if the index is negative
                if (index < 0)
                {
                    throw new IndexOutOfRangeException();
                }
                else
                {

                    while (count != index - 1)
                    {
                        count++;
                        //when the end of the list is reached,an Indexoutofrange exception is thrown
                        if (temp.Next == null)
                        {
                            throw new IndexOutOfRangeException();
                        }
                        else
                        {
                            temp = temp.Next;
                        }
                    }
                    //Add the Value between two elements
                    Value.Next = temp.Next;
                    temp.Next = Value;
                }
                
                
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine(e.Message);
            }
        }


        // Method to check if the list is empty.
        public bool IsEmpty()
        {
            return Head == null;
        }


        // Method to clear all items in the list.
        public void Clear()
        {
            Head = null;
        }


        // Method for replacing an item at a specific index.
        public void Replace(User newValue, int index)
        {

            // Index validation and new value
            if (index < 0 || newValue == null)
            {
                throw new ArgumentException("Index is out of bounds or newValue is null");
            }
            


            Node current = Head;
            for (int i = 0; i < index; i++)
            {
                if (current == null)
                {
                    throw new IndexOutOfRangeException("Index is out of the range of the list");
                }
                current = current.Next;
            }
            current.Value = newValue;
        }


        // Method to get an item at a specific index.
        public User GetValue(int index)
        {
            
            // Index validation
            if (index < 0)
            {
                throw new ArgumentException("Index is out of bounds");
            }
            


            Node current = Head;
            for(int i = 0;i < index; i++)
            {
                if(current == null)
                {
                    throw new IndexOutOfRangeException("Index is out of the range of the list");
                }
                current = current.Next;
            }
            return current.Value;
        }


        // Method to get the index of a specific item
        public int IndexOf(User item)
        {
            Node current = Head;
            int index = 0;
            while (current != null)
            {
                if (current.Value.Equals(item))
                {
                    return index;
                }
                current = current.Next;
                index++;
            }
            // Returns -1 if the item is not found.
            return -1; 
        }


        // Method to get the number of items in the list.
        public int Count()
        {
            Node current = Head;
            int count = 0;
            while (current != null)
            {
                count++;
                current = current.Next;
            }
            return count;
        }


        public bool Contains(User item)
        {
            return IndexOf(item) != -1;
        }


        public User[] ValuesIntoArray()
        {
            Node current = Head;
            int size = 0;

            while (current != null)
            {
                size++;
                current = current.Next;
            }
            
            // Returns an empty array
            if (size == 0)
            {
                return new User[0]; 
            }

            User[] newArray = new User[size];

            current = Head;
            int index = 0;

            while (current != null)
            {
                newArray[index++] = current.Value;
                current = current.Next;
            }
            
            // Returns the filled array
            return newArray;
        }


        public List<User> ValuesIntoList()
        {
            List<User> newList = new List<User>();
            Node current = Head;

            // Returns an empty list if the linked list is empty
            if (current == null)
            {
                return newList;
            }

            while (current != null)
            {
                newList.Add(current.Value);
                current = current.Next;
            }
            
            // Returns the filled list
            return newList;
        }
    }
}
