﻿using Assignment3.Utility;
using NUnit.Framework;

namespace Assignment3.Tests
{
    internal class LinkedListTest
    {
        [Test]
        public void Test_EmptyList()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            Assert.IsTrue(list.IsEmpty());
            Assert.AreEqual(0, list.Count());
        }

        [Test]
        public void Test_Prepend()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            list.AddFirst(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            Assert.AreEqual("Joe Blow", list.GetValue(0).Name);
        }

        [Test]
        public void Test_Append()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            list.AddLast(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));
            Assert.AreEqual("Joe Schmoe", list.GetValue(0).Name);
        }

        [Test]
        public void Test_InsertAtIndex()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            list.AddLast(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            list.AddLast(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));
            list.Add(new User(3, "Colonel Sanders", "chickenlover1890@gmail.com", "kfc5555"), 1);
            Assert.AreEqual("Colonel Sanders", list.GetValue(1).Name);
        }

        // An item is replaced.
        [Test]
        public void Test_Replace()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            list.AddLast(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            list.Replace(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"), 0);
            Assert.AreEqual("Joe Schmoe", list.GetValue(0).Name);
        }

        // An item is deleted from beginning of list.
        [Test]
        public void Test_RemoveFirst()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            list.AddLast(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            list.AddLast(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));
            list.RemoveFirst();
            Assert.AreEqual("Joe Schmoe", list.GetValue(0).Name);
        }

        // An item is deleted from end of list.
        [Test]
        public void Test_RemoveLast()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            list.AddLast(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            list.AddLast(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));
            list.RemoveLast();
            Assert.AreEqual("Joe Blow", list.GetValue(0).Name);
        }

        // An item is deleted from middle of list.
        [Test]
        public void Test_RemoveAtMiddle()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            list.AddLast(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            list.AddLast(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));
            list.AddLast(new User(3, "Colonel Sanders", "chickenlover1890@gmail.com", "kfc5555"));
            list.Remove(1);
            Assert.AreEqual("Colonel Sanders", list.GetValue(1).Name);
        }

        // An existing item is found and retrieved.
        [Test]
        public void Test_IndexOf()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            User john = new User(1, "Joe Blow", "jblow@gmail.com", "password");
            list.AddLast(john);
            Assert.AreEqual(0, list.IndexOf(john));
        }

        // Checks if a specific item exists in the list.
        [Test]
        public void Test_Contains()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            User user = new User(4, "Ronald McDonald", "burgers4life63@outlook.com", "mcdonalds999");
            list.AddLast(user);
            Assert.IsTrue(list.Contains(user));
        }
    }
}
