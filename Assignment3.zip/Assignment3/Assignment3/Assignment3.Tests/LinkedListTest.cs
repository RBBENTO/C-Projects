﻿using Assignment3.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Assignment3.Tests
{
    internal class LinkedListTest
    {
        private SiglyLinkedList users;

        [SetUp]
        public void Setup()
        {
            users = new SiglyLinkedList();

            users.AddLast(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            users.AddLast(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));
            users.AddLast(new User(3, "Colonel Sanders", "chickenlover1890@gmail.com", "kfc5555"));
            users.AddLast(new User(4, "Ronald McDonald", "burgers4life63@outlook.com", "mcdonalds999"));


        }
        [Test]
        public void Test_EmptyList()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            Assert.IsTrue(list.IsEmpty());
            Assert.AreEqual(0, list.Count());
        }

        [Test]
        public void Test_Prepend()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            list.AddFirst(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            Assert.AreEqual("Joe Blow", list.GetValue(0).Name);
        }

        [Test]
        public void Test_Append()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            list.AddLast(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));
            Assert.AreEqual("Joe Schmoe", list.GetValue(0).Name);
        }

        [Test]
        public void Test_InsertAtIndex()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            list.AddLast(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            list.AddLast(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));
            list.Add(new User(3, "Colonel Sanders", "chickenlover1890@gmail.com", "kfc5555"), 1);
            Assert.AreEqual("Colonel Sanders", list.GetValue(1).Name);
        }

        
        [Test]
        public void Test_Replace()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            list.AddLast(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            list.Replace(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"), 0);
            Assert.AreEqual("Joe Schmoe", list.GetValue(0).Name);
        }

        
        [Test]
        public void Test_RemoveFirst()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            list.AddLast(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            list.AddLast(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));
            list.RemoveFirst();
            Assert.AreEqual("Joe Schmoe", list.GetValue(0).Name);
        }

        
        [Test]
        public void Test_RemoveLast()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            list.AddLast(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            list.AddLast(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));
            list.RemoveLast();
            Assert.AreEqual("Joe Blow", list.GetValue(0).Name);
        }

        
        [Test]
        public void Test_RemoveAtMiddle()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            list.AddLast(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            list.AddLast(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));
            list.AddLast(new User(3, "Colonel Sanders", "chickenlover1890@gmail.com", "kfc5555"));
            list.Remove(1);
            Assert.AreEqual("Colonel Sanders", list.GetValue(1).Name);
        }

        
        [Test]
        public void Test_IndexOf()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            User john = new User(1, "Joe Blow", "jblow@gmail.com", "password");
            list.AddLast(john);
            Assert.AreEqual(0, list.IndexOf(john));
        }

        
        [Test]
        public void Test_Contains()
        {
            SiglyLinkedList list = new SiglyLinkedList();
            User user = new User(4, "Ronald McDonald", "burgers4life63@outlook.com", "mcdonalds999");
            list.AddLast(user);
            Assert.IsTrue(list.Contains(user));
        }

        [Test]
        public void Test_ValuesIntoArray()
        {
            var resultArray = users.ValuesIntoArray();
            Assert.IsNotNull(resultArray);
            Assert.AreEqual(4, resultArray.Length);
            Assert.AreEqual("Joe Blow", resultArray[0].Name);
            Assert.AreEqual("Joe Schmoe", resultArray[1].Name);
            Assert.AreEqual("Colonel Sanders", resultArray[2].Name);
            Assert.AreEqual("Ronald McDonald", resultArray[3].Name);
        }

        [Test]
        public void Test_ValuesIntoList()
        {
            var resultList = users.ValuesIntoList();
            Assert.IsNotNull(resultList);
            Assert.AreEqual(4, resultList.Count);
            Assert.AreEqual("Joe Blow", resultList[0].Name);
            Assert.AreEqual("Joe Schmoe", resultList[1].Name);
            Assert.AreEqual("Colonel Sanders", resultList[2].Name);
            Assert.AreEqual("Ronald McDonald", resultList[3].Name);
        }
    }
}

