﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using Assignment3.Utility;

namespace Assignment3.Tests
{
    public static class SerializationHelper
    {
        //This method serialize the objects (User) into the file created
        public static void SerializeUsers(SiglyLinkedList users, string fileName)
        {
            List<User> userList = new List<User>();
            Node currentNode = users.Head;
            while (currentNode != null)
            {
                userList.Add(currentNode.Value);
                currentNode = currentNode.Next;
            }

            DataContractSerializer serializer = new DataContractSerializer(typeof(List<User>));
            using (FileStream stream = File.Create(fileName))
            {
                serializer.WriteObject(stream, userList);
            }
        }

        ////This method deserialize the objects (User) from the file
        public static SiglyLinkedList DeserializeUsers(string fileName)
        {
            DataContractSerializer serializer = new DataContractSerializer(typeof(List<User>));
            using (FileStream stream = File.OpenRead(fileName))
            {
                List<User> userList = (List<User>)serializer.ReadObject(stream);

                SiglyLinkedList users = new SiglyLinkedList();
                foreach (User user in userList)
                {
                    users.AddLast(user);
                }
                return users;
            }
        }
    }
}